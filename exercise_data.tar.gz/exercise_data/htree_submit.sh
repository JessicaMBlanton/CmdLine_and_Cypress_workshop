#!/bin/bash   
#SBATCH --job-name=h_tree       ### Job Name
#SBATCH --output=h_tree.out   ### File in which to store job output
#SBATCH --error=h_tree.err   ### File in which to store job error messages
#SBATCH --partition=workshop   ### partition for Cypress- defaut usually defq
#SBATCH --qos=workshop   ### Quality of service parameter
#SBATCH --time=0-00:05:00   ### Wall clock time limit in Days-HH:MM:SS
#SBATCH --nodes=1   ### Number of nodes to use
#SBATCH --ntasks-per-node=1   ### Number of tasks to run per onde
#SBATCH --cpus-per-task=1  ### Number of cpus to use

# muscle 5.1.linux64 
module load muscle/5.1

# FastTree version 2.1.10
module load qiime2/2018.2

# Set up directory for output files
mkdir hominid_tree

# Align sequences
muscle -align hominid_cytb.fna -output hominid_tree/aln.fna -threads 1 -log hominid_tree/muscle_aln.log ;

# FastTree version 2.1.10 Double precision
FastTree -log hominid_tree/fasttree.log -nt hominid_tree/aln.fna > hominid_tree/h_tree.nwk

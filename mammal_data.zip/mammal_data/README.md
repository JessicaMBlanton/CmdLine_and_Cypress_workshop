This directory contains the following files:

**Tobe_2010_mito_ST1.txt** - Index file as flatfile, a modified version of Supplemental Table 1 from Tobe, Shanan S., Andrew C. Kitchener, and Adrian MT Linacre. "Reconstructing mammalian phylogenies: a detailed comparison of the cytochrome b and cytochrome oxidase subunit I mitochondrial genes." PloS one 5.11 (2010): e14156.

**Tobe_2010_mito_ST1.xlsx** - Index file as above, in Microsoft Excel format

**gene.fna** - selected "cytB" genes retrived from NCBI, unmodified

**primate_cytb.fna** - sequences from gene.fna, with headers modified for phylogenetic tree

